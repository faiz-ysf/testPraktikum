package burhanfess.users;

public class User {
    private static int idGenerator = 0;
    private final int id;
    private final String username;
    private String password;

    public User(String username, String password) {
        this.id = ++idGenerator;
        this.username = username;
        this.password = password;
    }

    public String getRole() { return "User"; }
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public void setPassword(String newPassword) {
        this.password = newPassword;
    }
    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', role=" + getRole() + "}";
    }
}
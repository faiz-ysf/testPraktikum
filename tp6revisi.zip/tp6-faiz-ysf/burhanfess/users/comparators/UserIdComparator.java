package burhanfess.users.comparators;

import java.util.Comparator;
import burhanfess.users.User;

public class UserIdComparator implements Comparator<User> {
    @Override
    public int compare(User user, User other) {
        return Integer.compare(user.getId(), other.getId());
    }
}
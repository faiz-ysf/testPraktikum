package burhanfess.users.comparators;

import java.util.Comparator;
import burhanfess.users.User;

public class UserUsernameComparator implements Comparator<User> {
    @Override
    public int compare(User user, User other) {
        return user.getUsername().compareTo(other.getUsername());
    }
}

package burhanfess;

import burhanfess.displays.Display;
import burhanfess.displays.UnauthorizedDisplay;
import burhanfess.exceptions.EmptyListException;
import burhanfess.services.UnauthorizedServiceImpl;

public class BurhanFess {
    private Display<?> currentDisplay;

    public void run() throws EmptyListException {
        while (true) {
            currentDisplay.run();
        }
    }

    public void setCurrentDisplay(Display<?> display) {
        this.currentDisplay = display;
    }

    public static void main(String[] args) throws EmptyListException {
        BurhanFess app = new BurhanFess();
        app.setCurrentDisplay(new UnauthorizedDisplay(new UnauthorizedServiceImpl(), app));
        app.run();
    }
}
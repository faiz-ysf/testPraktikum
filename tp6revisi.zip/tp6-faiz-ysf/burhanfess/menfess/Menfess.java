package burhanfess.menfess;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import burhanfess.users.User;

public class Menfess {
    private static int idGenerator = 0;
    protected static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    protected int id;
    protected LocalDateTime timestamp;
    protected String content;
    protected boolean isHidden;
    protected User user;

    public Menfess(User user, String content) {
        this.id = ++idGenerator;
        this.timestamp = LocalDateTime.now();
        this.content = content;
        this.isHidden = false;
        this.user = user;
    }

    public User getUser() { return user; }
    public boolean isHidden() { return isHidden; }
    public int getId() { return id; }
    public String getContent() { return content; }
    public void hide() { isHidden = true; }
    public void unhide() { isHidden = false; }
    public String getType() { return "Menfess"; }
    @Override
    public String toString() {
        return "[" + getType() + "] #" + id + " by " + user.getUsername() +
               " at " + timestamp.format(formatter) +
               (isHidden ? " [HIDDEN]" : "") +
               ": " + content;
    }
}
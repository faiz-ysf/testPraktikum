package burhanfess.menfess;

import burhanfess.users.User;

public class PromosiFess extends Menfess {
    public PromosiFess(User user, String content) {
        super(user, content);
    }
    @Override
    public String toString() {
        // For public and sent lists, sender is "anonim"
        return """
               [Confession] oleh anonim
               ID: """ + id +
            "\n" + content +
            "\nDikirim pada " + timestamp.format(formatter);
    }
}
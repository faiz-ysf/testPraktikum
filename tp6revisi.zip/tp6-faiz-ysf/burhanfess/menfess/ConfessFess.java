package burhanfess.menfess;

import burhanfess.users.User;

public class ConfessFess extends Menfess {
    private User receiver;

    public ConfessFess(User user, String content, User receiver) {
        super(user, content);
        this.receiver = receiver;
    }

    public User getReceiver() { return receiver; }
    @Override
    public String getType() { return "ConfessFess"; }
    @Override
    public String toString() {
        return "[" + getType() + "] #" + id + " from " + user.getUsername() +
               " to " + receiver.getUsername() +
               " at " + timestamp.format(formatter) +
               (isHidden ? " [HIDDEN]" : "") +
               ": " + content;
    }
}
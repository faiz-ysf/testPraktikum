package burhanfess.exceptions;

public class EmptyContentException extends Exception {
    public EmptyContentException(String message) {
        super(message);
    }
}
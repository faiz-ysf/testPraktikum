package burhanfess.exceptions;

public class FileOperationException extends Exception {
    public FileOperationException(String message) {
        super(message);
    }
}
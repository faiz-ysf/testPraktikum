package burhanfess.exceptions;

public class CosmicAccountNotFoundException extends Exception {
    public CosmicAccountNotFoundException(String message) {
        super(message);
    }
}

package burhanfess.exceptions;

public class InvalidMenfessTypeException extends Exception {
    public InvalidMenfessTypeException(String message) {
        super(message);
    }
}
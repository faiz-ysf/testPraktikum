package burhanfess.exceptions;

public class MenfessNotFoundException extends Exception {
    public MenfessNotFoundException(String message) {
        super(message);
    }
}

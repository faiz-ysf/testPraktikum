package burhanfess.repositories;

import burhanfess.exceptions.EmptyListException;
import burhanfess.users.User;
import java.util.List;

public interface UserRepository {
    List<User> getAllUsers() throws EmptyListException;
    User getUserByUsername(String username);
    void addUser(User user);
    void changePassword(User user, String newPassword);
}
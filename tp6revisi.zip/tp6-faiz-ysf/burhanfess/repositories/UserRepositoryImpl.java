package burhanfess.repositories;

import burhanfess.exceptions.EmptyListException;
import burhanfess.users.Admin;
import burhanfess.users.User;
import java.util.List;

public class UserRepositoryImpl extends GenericRepositoryImpl<User> implements UserRepository {
    private static UserRepository instance;
    private static final String DEFAULT_ADMIN_USERNAME = "FYR";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";

    public UserRepositoryImpl() {
        super();
        initializeDefaultAdmin();
    }

    public static UserRepository getInstance() {
        if (instance == null) {
            instance = new UserRepositoryImpl();
        }
        return instance;
    }

    @Override
    public List<User> getAllUsers() throws EmptyListException {
        List<User> users = getAll();
        if (users.isEmpty()) {
            throw new EmptyListException("Tidak ada pengguna.");
        }
        return users;
    }

    @Override
    public User getUserByUsername(String username) {
        if (username == null) {
            throw new IllegalArgumentException("Username cannot be null");
        }
        for (User user : data) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    @Override
    public void addUser(User user) {
        add(user);
    }

    @Override
    public void changePassword(User user, String newPassword) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        if (newPassword == null) {
            throw new IllegalArgumentException("New password cannot be null");
        }
        user.setPassword(newPassword);
    }

    private void initializeDefaultAdmin() {
        add(new Admin(DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD));
    }
}
package burhanfess.repositories;

import java.util.List;

public interface GenericRepository<T> {
    void add(T obj);
    void remove(T obj);
    List<T> getAll();
}

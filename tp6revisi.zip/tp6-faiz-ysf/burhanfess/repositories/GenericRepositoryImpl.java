package burhanfess.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class GenericRepositoryImpl<T> implements GenericRepository<T> {
    protected List<T> data = new ArrayList<>();

    @Override
    public void add(T obj) {
        if (obj == null) {
            throw new IllegalArgumentException("Object to add cannot be null");
        }
        data.add(obj);
    }

    @Override
    public void remove(T obj) {
        if (obj == null) {
            throw new IllegalArgumentException("Object to remove cannot be null");
        }
        data.remove(obj);
    }

    @Override
    public List<T> getAll() {
        return new ArrayList<>(data);
    }

    protected List<T> filter(Predicate<T> predicate) {
        List<T> result = new ArrayList<>();
        for (T item : data) {
            if (predicate.test(item)) {
                result.add(item);
            }
        }
        return result;
    }
}
package burhanfess.repositories;

import burhanfess.menfess.Menfess;
import burhanfess.users.User;
import java.util.List;

public class MenfessRepositoryImpl extends GenericRepositoryImpl<Menfess> implements MenfessRepository {
    private static MenfessRepository instance;

    public MenfessRepositoryImpl() {
        super();
    }

    public static MenfessRepository getInstance() {
        if (instance == null) {
            instance = new MenfessRepositoryImpl();
        }
        return instance;
    }

    @Override
    public List<Menfess> getAllMenfessesByUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        return filter(menfess -> menfess.getUser().equals(user));
    }

    @Override
    public List<Menfess> getAllHiddenMenfesses() {
        return filter(Menfess::isHidden);
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() {
        return filter(menfess -> !menfess.isHidden());
    }

    @Override
    public void addMenfess(Menfess menfess) {
        add(menfess);
    }

    @Override
    public void hideMenfess(Menfess menfess) {
        if (menfess == null) {
            throw new IllegalArgumentException("Menfess cannot be null");
        }
        if (!data.contains(menfess)) {
            throw new RuntimeException("Menfess tidak ditemukan di repository.");
        }
        menfess.hide();
    }

    @Override
    public void unhideMenfess(Menfess menfess) {
        if (menfess == null) {
            throw new IllegalArgumentException("Menfess cannot be null");
        }
        if (!data.contains(menfess)) {
            throw new RuntimeException("Menfess tidak ditemukan di repository.");
        }
        menfess.unhide();
    }

    @Override
    public List<Menfess> getAllMenfessesForUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        return filter(menfess ->
                menfess instanceof burhanfess.menfess.ConfessFess &&
                        ((burhanfess.menfess.ConfessFess) menfess).getReceiver().equals(user)
        );
    }
}
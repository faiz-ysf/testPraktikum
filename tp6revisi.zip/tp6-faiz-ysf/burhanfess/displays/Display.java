package burhanfess.displays;

import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import burhanfess.exceptions.EmptyListException;
import burhanfess.users.User;

public interface Display<T extends User> {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    Scanner scanner = new Scanner(System.in);

    void run() throws EmptyListException;
    void showMenu() throws EmptyListException;
    void showHeader();
    void showFooter();
    void showCurrentDate();
    T getCurrentUser() throws EmptyListException;
}
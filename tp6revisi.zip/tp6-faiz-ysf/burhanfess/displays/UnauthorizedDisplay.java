package burhanfess.displays;

import burhanfess.BurhanFess;
import burhanfess.services.AdminServiceImpl;
import burhanfess.services.CosmicServiceImpl;
import burhanfess.services.UnauthorizedService;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import java.util.Scanner;

public class UnauthorizedDisplay implements Display<User> {
    private final UnauthorizedService unauthorizedService;
    private final Scanner scanner = new Scanner(System.in);
    private final BurhanFess app;

    public UnauthorizedDisplay(UnauthorizedService unauthorizedService, BurhanFess app) {
        if (unauthorizedService == null || app == null) {
            throw new IllegalArgumentException("Parameters cannot be null");
        }
        this.unauthorizedService = unauthorizedService;
        this.app = app;
    }

    @Override
    public User getCurrentUser() {
        return null;
    }

    @Override
    public void showMenu() {
        while (true) {
            showHeader();
            System.out.println("Silakan pilih salah satu opsi berikut.");
            System.out.println("1. Registrasi");
            System.out.println("2. Login");
            System.out.println("3. Keluar");
            System.out.print("Masukkan pilihan: ");
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1" -> register();
                case "2" -> {
                    login();
                    return;
                }
                case "3" -> {
                    exit();
                    return;
                }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }

    @Override
    public void showHeader() {
        System.out.println("Selamat datang di BurhanFess");
        showCurrentDate();
        System.out.println("------------------------------------------------------------");
    }

    @Override
    public void showFooter() {
        System.out.println("------------------------------------------------------------");
        System.out.println("BurhanFess - 2025");
        System.out.println("Created by Faiz Yusuf Ridwan");
    }

    @Override
    @SuppressWarnings("deprecation")
    public void showCurrentDate() {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.time.format.DateTimeFormatter formatter =
                java.time.format.DateTimeFormatter.ofPattern("E, dd MMMM yyyy", new java.util.Locale("id", "ID"));
        System.out.println(today.format(formatter));
    }

    @Override
    public void run() {
        showMenu();
    }

    public void register() {
        System.out.println("\nSilakan masukkan username dan password untuk registrasi:");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();
        try {
            unauthorizedService.register(username, password);
            System.out.println("Registrasi berhasil! Silakan login.");
        } catch (burhanfess.exceptions.UserAlreadyExistsException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void login() {
        System.out.println("\nSilakan masukkan username dan password untuk login:");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();

        try {
            User user = unauthorizedService.login(username, password);
            if (user.getRole().equals("Admin")) {
                app.setCurrentDisplay(new AdminDisplay((Admin) user, new AdminServiceImpl(), app));
            } else if (user.getRole().equals("Cosmic")) {
                app.setCurrentDisplay(new CosmicDisplay((Cosmic) user, new CosmicServiceImpl((Cosmic) user), app));
            }
        } catch (burhanfess.exceptions.UserNotFoundException | burhanfess.exceptions.InvalidCredentialsException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    @SuppressWarnings("all")
    public void exit() {
        System.out.println("");
        System.out.println("Terima kasih telah menggunakan BurhanFess. Sampai Jumpa!");
        showFooter();
        System.exit(0);
    }
}
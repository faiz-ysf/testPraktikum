package burhanfess.displays;

import burhanfess.BurhanFess;
import burhanfess.menfess.Menfess;
import burhanfess.services.CosmicService;
import burhanfess.services.UnauthorizedServiceImpl;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import java.util.List;


@SuppressWarnings("all")
public class CosmicDisplay implements Display<Cosmic> {
    private final Cosmic cosmic;
    private final CosmicService cosmicService;
    private final BurhanFess app;

    public CosmicDisplay(Cosmic cosmic, CosmicService cosmicService, BurhanFess app) {
        if (cosmic == null || cosmicService == null || app == null) {
            throw new IllegalArgumentException("Parameters cannot be null");
        }
        this.cosmic = cosmic;
        this.cosmicService = cosmicService;
        this.app = app;
    }

    @Override
    public Cosmic getCurrentUser() {
        return cosmic;
    }

    @Override
    public void showMenu() {
        showHeader();

        while (true) {
            System.out.println("Silakan pilih salah satu opsi berikut.");
            System.out.println("1. Mengirim satu menfess");
            System.out.println("2. Melihat menfess publik");
            System.out.println("3. Melihat menfess yang kamu kirim");
            System.out.println("4. Melihat menfess yang kamu terima");
            System.out.println("5. Leaderboard menfess");
            System.out.println("6. Ubah password");
            System.out.println("7. Hapus Menfess Saya");
            System.out.println("8. Logout");
            System.out.print("Masukkan pilihan: ");
            String input = scanner.nextLine().trim();
            switch (input) {
                case "1" -> { System.out.println(""); sendMenfess();           System.out.println(""); }
                case "2" -> { System.out.println(""); viewUnhiddenMenfesses(); System.out.println(""); }
                case "3" -> { System.out.println(""); viewSentMenfesses();     System.out.println(""); }
                case "4" -> { System.out.println(""); viewReceivedMenfesses(); System.out.println(""); }
                case "5" -> { System.out.println(""); showLeaderboard();       System.out.println(""); }
                case "6" -> { System.out.println(""); changePassword();        System.out.println(""); }
                case "7" -> { System.out.println(""); deleteSentMenfess();     System.out.println(""); }
                case "8" -> { System.out.println(""); logout();                                return; }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }

    @Override
    public void showHeader() {
        System.out.println("Halo, Cosmic " + cosmic.getUsername() + "!");
        showCurrentDate();
        System.out.println("------------------------------------------------------------");
    }

    @Override
    public void showFooter() {
        System.out.println("------------------------------------------------------------");
        System.out.println("BurhanFess - 2025");
        System.out.println("Created by Faiz Yusuf Ridwan");
    }

    @Override
    @SuppressWarnings("deprecation")
    public void showCurrentDate() {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.time.format.DateTimeFormatter formatter =
                java.time.format.DateTimeFormatter.ofPattern("E, dd MMMM yyyy", new java.util.Locale("id", "ID"));
        System.out.println(today.format(formatter));
    }

    @Override
    public void run() {
        showMenu();
    }

    public void sendMenfess() {
        System.out.print("Masukkan isi menfess yang ingin kamu kirim: ");
        String content = scanner.nextLine().trim();

        System.out.println("Silakan pilih tipe menfess yang ingin dikirim.");
        System.out.println("1. Curhat");
        System.out.println("2. Promosi");
        System.out.println("3. Confession");
        System.out.print("Masukkan tipe menfess: ");
        String tipe = scanner.nextLine().trim();

        try {
            switch (tipe) {
                case "1" -> {
                    cosmicService.sendCurhatFess(content);
                    System.out.println("Menfess berhasil dikirim.");
                }
                case "2" -> {
                    cosmicService.sendPromosiFess(content);
                    System.out.println("Menfess berhasil dikirim.");
                }
                case "3" -> {
                    System.out.print("Masukkan username yang ingin kamu kirimkan menfess: ");
                    String receiverUsername = scanner.nextLine().trim();
                    cosmicService.sendConfessFess(content, receiverUsername);
                    System.out.println("Menfess berhasil dikirim.");
                }
                default -> System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } catch (burhanfess.exceptions.EmptyContentException e) {
            System.out.println(e.getMessage());
        } catch (burhanfess.exceptions.UserNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void viewUnhiddenMenfesses() {
        try {
            List<Menfess> menfesses = cosmicService.getAllUnhiddenMenfesses();
            if (menfesses.isEmpty()) {
                System.out.println("Tidak ada menfess publik.");
            } else {
                System.out.println("Daftar menfess bersifat publik:");
                for (Menfess m : menfesses) {
                    System.out.println(m);
                }
            }
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void viewSentMenfesses() {
        try {
            List<Menfess> menfesses = cosmicService.getAllSentMenfesses();
            if (menfesses.isEmpty()) {
                System.out.println("Tidak ada menfess yang kamu kirim.");
            } else {
                System.out.println("Daftar menfess yang kamu kirim:");
                for (Menfess m : menfesses) {
                    System.out.println(m);
                }
            }
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void viewReceivedMenfesses() {
        try {
            List<Menfess> menfesses = cosmicService.getAllReceivedMenfesses();
            if (menfesses.isEmpty()) {
                System.out.println("Tidak ada menfess yang kamu terima.");
            } else {
                System.out.println("Daftar menfess yang kamu terima:");
                for (Menfess m : menfesses) {
                    System.out.println(m);
                }
            }
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void showLeaderboard() {
        try {
            List<User> top = cosmicService.getTopCosmics(5);
            int rank = cosmicService.getCosmicRank(cosmic.getUsername());
            int count = cosmicService.getMenfessCount(cosmic.getUsername());
            System.out.println("Menfess Ranking: ");
            for (int i = 0; i < top.size(); i++) {
                System.out.println("Rank " + (i + 1) + " : " +
                        top.get(i).getUsername() + " - " +
                        cosmicService.getMenfessCount(top.get(i).getUsername()) + " Menfess");
            }
            System.out.println("Rank anda: " + rank);
            System.out.println("Jumlah menfess dikirim: " + count);
        } catch (Exception e) {
            System.out.println("Gagal menampilkan leaderboard: "  + e.getMessage());
        }
    }

    public void deleteSentMenfess() {
        try {
            List<Menfess> sent = cosmicService.getAllSentMenfesses();
            if (sent.isEmpty()) {
                System.out.println("Tidak ada menfess yang kamu kirim.");
                return;
            }
            System.out.println("Daftar menfess yang kamu kirim:");
            for (Menfess m : sent) {
                System.out.println(m);
            }
            System.out.print("Masukan ID menfess yang ingin dihapus: ");
            String input = scanner.nextLine().trim();
            int id = Integer.parseInt(input);
            cosmicService.deleteSentMenfess(id);
            System.out.println("Menfess dengan ID " + id + " berhasil dihapus!");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void changePassword() {
        System.out.print("Masukkan password baru: ");
        String newPassword = scanner.nextLine().trim();
        try {
            cosmicService.changePassword(newPassword);
            System.out.println("Password berhasil diubah.");
        } catch (burhanfess.exceptions.SamePasswordException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void logout() {
        System.out.println("");
        System.out.println("Kamu telah berhasil logout.");
        showFooter();
        app.setCurrentDisplay(new UnauthorizedDisplay(new UnauthorizedServiceImpl(), app));
    }
}
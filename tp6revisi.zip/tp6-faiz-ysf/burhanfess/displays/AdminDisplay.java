package burhanfess.displays;

import burhanfess.BurhanFess;
import burhanfess.exceptions.EmptyListException;
import burhanfess.menfess.Menfess;
import burhanfess.services.AdminService;
import burhanfess.services.UnauthorizedServiceImpl;
import burhanfess.users.Admin;
import burhanfess.users.User;
import java.util.List;

@SuppressWarnings("all")
public class AdminDisplay implements Display<Admin> {
    private final Admin admin;
    private final AdminService adminService;
    private final BurhanFess app;

    public AdminDisplay(Admin admin, AdminService adminService, BurhanFess app) {
        if (admin == null || adminService == null || app == null) {
            throw new IllegalArgumentException("Parameters cannot be null");
        }
        this.admin = admin;
        this.adminService = adminService;
        this.app = app;
    }

    @Override
    public Admin getCurrentUser() {
        return admin;
    }

    @Override
    public void showMenu() throws EmptyListException {
        while (true) {
            System.out.println("Silakan pilih salah satu opsi berikut.");
            System.out.println("1. Lihat daftar pengguna");
            System.out.println("2. Tambah admin");
            System.out.println("3. Reset password pengguna");
            System.out.println("4. Hapus Akun Cosmic");
            System.out.println("5. Sembunyikan menfess");
            System.out.println("6. Tampilkan menfess");
            System.out.println("7. Buat Logfile Sistem");
            System.out.println("8. Statistik User");
            System.out.println("9. Logout");
            System.out.print("Masukkan pilihan: ");
            String input = scanner.nextLine().trim();
            switch (input) {
                case "1" -> { System.out.println(""); showAllUsers();          System.out.println(""); }
                case "2" -> { System.out.println(""); addAdmin();              System.out.println(""); }
                case "3" -> { System.out.println(""); resetPassword();         System.out.println(""); }
                case "4" -> { System.out.println(""); deleteCosmicAccount();   System.out.println(""); }
                case "5" -> { System.out.println(""); hideMenfess();           System.out.println(""); }
                case "6" -> { System.out.println(""); unhideMenfess();         System.out.println(""); }
                case "7" -> { System.out.println(""); exportLoginLog();        System.out.println(""); }
                case "8" -> { System.out.println(""); showCosmicStatistics();  System.out.println(""); }
                case "9" -> { System.out.println(""); logout();                                return; }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }

    @Override
    public void showHeader() {
        System.out.println("Halo, Admin " + admin.getUsername() + "!");
        showCurrentDate();
        System.out.println("------------------------------------------------------------");
    }

    @Override
    public void showFooter() {
        System.out.println("------------------------------------------------------------");
        System.out.println("BurhanFess - 2025");
        System.out.println("Created by Faiz Yusuf Ridwan");
    }

    @Override
    public void showCurrentDate() {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.time.format.DateTimeFormatter formatter =
                java.time.format.DateTimeFormatter.ofPattern("E, dd MMMM yyyy", new java.util.Locale("id", "ID"));
        System.out.println(today.format(formatter));
    }

    @Override
    public void run() throws EmptyListException {
        showMenu();
    }

    public void showAllUsers() {
        try {
            System.out.println("Silakan pilih opsi pengurutan:");
            System.out.println("1. Berdasarkan ID");
            System.out.println("2. Berdasarkan username");
            System.out.print("Masukkan pilihan: ");
            String input = scanner.nextLine().trim();

            List<User> users;
            switch (input) {
                case "1" -> {
                    users = adminService.getAllUsers(new burhanfess.users.comparators.UserIdComparator());
                    System.out.println("Daftar pengguna diurutkan berdasarkan ID:");
                }
                case "2" -> {
                    users = adminService.getAllUsers(new burhanfess.users.comparators.UserUsernameComparator());
                    System.out.println("Daftar pengguna diurutkan berdasarkan username:");
                }
                default -> {
                    System.out.println("Input tidak valid. Silakan coba lagi.");
                    return;
                }
            }

            for (User user : users) {
                System.out.println("ID: " + user.getId() + ", Username: " + user.getUsername());
            }
        } catch (burhanfess.exceptions.EmptyListException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void addAdmin() {
        try {
            System.out.println("Silakan masukkan username dan password untuk admin baru:");
            System.out.print("Username: ");
            String username = scanner.nextLine().trim();
            System.out.print("Password: ");
            String password = scanner.nextLine().trim();
            adminService.addAdmin(username, password);
            System.out.println("Admin " + username + " berhasil ditambahkan");
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void resetPassword() {
        System.out.print("Masukkan username pengguna yang passwordnya ingin direset: ");
        String username = scanner.nextLine().trim();
        if (username.isEmpty()) {
            System.out.println("Username tidak boleh kosong.");
            return;
        }
        System.out.print("Masukkan password baru: ");
        String newPassword = scanner.nextLine().trim();
        if (newPassword.isEmpty()) {
            System.out.println("Password baru tidak boleh kosong.");
            return;
        }
        try {
            adminService.resetPassword(username, newPassword);
            System.out.println("Password berhasil direset.");
        } catch (burhanfess.exceptions.UserNotFoundException | burhanfess.exceptions.SamePasswordException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void hideMenfess() {
        try {
            List<Menfess> menfesses = adminService.getAllUnhiddenMenfesses();
            if (menfesses.isEmpty()) {
                System.out.println("Tidak ada menfess yang dapat disembunyikan.");
                return;
            }
            System.out.println("Daftar menfess yang ditampilkan:");
            for (Menfess m : menfesses) {
                System.out.println(m);
            }
            System.out.print("Masukkan ID menfess yang ingin disembunyikan: ");
            String input = scanner.nextLine().trim();
            try {
                int id = Integer.parseInt(input);
                adminService.hideMenfess(id);
                System.out.println("Menfess berhasil disembunyikan.");
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid. Silakan masukkan angka yang sesuai.");
            }
        } catch (burhanfess.exceptions.EmptyListException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void unhideMenfess() {
        try {
            List<Menfess> menfesses = adminService.getAllHiddenMenfesses();
            if (menfesses.isEmpty()) {
                System.out.println("Tidak ada menfess yang disembunyikan.");
                return;
            }
            System.out.println("Daftar menfess yang disembunyikan:");
            for (Menfess m : menfesses) {
                System.out.println(m);
            }
            System.out.print("Masukkan ID menfess yang ingin ditampilkan kembali: ");
            String input = scanner.nextLine().trim();
            try {
                int id = Integer.parseInt(input);
                adminService.unhideMenfess(id);
                System.out.println("Menfess berhasil ditampilkan.");
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid. Silakan masukkan angka yang sesuai.");
            }

        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }

    public void deleteCosmicAccount() {
        System.out.println("Masukkan username akun yang ingin dihapus: ");
        String username = scanner.nextLine().trim();
        try {
            adminService.deleteCosmicAccount(username);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void exportLoginLog() {
        try {
            adminService.exportLoginLogToFile("logFile.txt");
        } catch (Exception e) {
            System.out.println("Gagal membuat file log: " + e.getMessage());
        }
    }

    public void showCosmicStatistics() throws EmptyListException {
        List<String[]> stats = adminService.getCosmicStatistics();
        System.out.println("+------------------+-----------+----------+-----------+------------------------+");
        System.out.println("| Username         | Confess   | Curhat   | Promosi   | Menfess Diterima       |");
        System.out.println("+------------------+-----------+----------+-----------+------------------------+");
        for (String[] row : stats) {
            System.out.printf("| %-12s | %7s | %6s | %7s | %18s |\n", row[0], row[1], row[2], row[3], row[4]);
        }
        System.out.println("+------------------+-----------+----------+-----------+------------------------+");
        System.out.println("Total pengguna terdaftar: " + stats.size());
    }

    public void logout() {
        System.out.println("");
        System.out.println("Kamu telah berhasil logout.");
        showFooter();
        app.setCurrentDisplay(new UnauthorizedDisplay(new UnauthorizedServiceImpl(), app));
    }
}
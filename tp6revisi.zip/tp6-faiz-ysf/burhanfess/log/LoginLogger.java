package burhanfess.log;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class LoginLogger {
    private static final Map<String, List<String>> logMap = new HashMap<>();
    private static final DateTimeFormatter TS_FMT =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public static void log(String username, String timestamp) {
        logMap.computeIfAbsent(username, k -> new ArrayList<>()).add(timestamp);
    }

    public static Map<String, List<String>> getLogMap() {
        return logMap;
    }

    // Returns the current daily streak based on distinct calendar days,
    // counting back from today. Multiple logins in one day count as one.
    public static int getCurrentDailyStreak(String username) {
        List<String> logs = logMap.get(username);
        if (logs == null || logs.isEmpty()) return 0;

        // Parse timestamps to LocalDate, unique per day
        Set<LocalDate> uniqueDays = new HashSet<>();
        for (String ts : logs) {
            try {
                LocalDateTime dt = LocalDateTime.parse(ts, TS_FMT);
                uniqueDays.add(dt.toLocalDate());
            } catch (Exception ignored) {
            }
        }
        if (uniqueDays.isEmpty()) return 0;

        // Build a descending sorted list of dates
        List<LocalDate> days = new ArrayList<>(uniqueDays);
        days.sort(Comparator.reverseOrder());

        LocalDate today = LocalDate.now();
        if (!uniqueDays.contains(today)) {
            // No login today; streak is 0 (resets)
            return 0;
        }

        // Count consecutive days including today going backward
        int streak = 0;
        LocalDate cursor = today;
        while (uniqueDays.contains(cursor)) {
            streak++;
            cursor = cursor.minusDays(1);
        }
        return streak;
    }
}

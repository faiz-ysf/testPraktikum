package burhanfess.services;

import burhanfess.exceptions.EmptyContentException;
import burhanfess.exceptions.EmptyListException;
import burhanfess.exceptions.SamePasswordException;
import burhanfess.exceptions.UserNotFoundException;
import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.menfess.PromosiFess;
import burhanfess.repositories.MenfessRepository;
import burhanfess.repositories.MenfessRepositoryImpl;
import burhanfess.repositories.UserRepository;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.repositories.GenericRepositoryImpl;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import java.util.List;

public class CosmicServiceImpl implements CosmicService {
    private final Cosmic cosmic;
    private final UserRepository userRepository;
    private final MenfessRepository menfessRepository;

    public CosmicServiceImpl(Cosmic cosmic) {
        if (cosmic == null) {
            throw new IllegalArgumentException("Cosmic user cannot be null");
        }
        this.cosmic = cosmic;
        this.userRepository = UserRepositoryImpl.getInstance();
        this.menfessRepository = MenfessRepositoryImpl.getInstance();
    }

    @Override
    public void sendCurhatFess(String content) throws EmptyContentException {
        validateContent(content);
        menfessRepository.addMenfess(new CurhatFess(cosmic, content));
    }

    @Override
    public void sendPromosiFess(String content) throws EmptyContentException {
        validateContent(content);
        menfessRepository.addMenfess(new PromosiFess(cosmic, content));
    }

    @Override
    public void sendConfessFess(String content, String receiverUsername) throws UserNotFoundException, EmptyContentException {
        validateContent(content);
        if (receiverUsername == null || receiverUsername.trim().isEmpty()) {
            throw new IllegalArgumentException("Receiver username cannot be null or empty");
        }
        User receiver = userRepository.getUserByUsername(receiverUsername);
        if (receiver == null) {
            throw new UserNotFoundException("User dengan username '" + receiverUsername + "' tidak ditemukan");
        }
        menfessRepository.addMenfess(new ConfessFess(cosmic, content, receiver));
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() throws EmptyListException {
        List<Menfess> menfesses = menfessRepository.getAllUnhiddenMenfesses();
        if (menfesses == null || menfesses.isEmpty()) {
            throw new EmptyListException("Tidak ada menfess publik.");
        }
        return menfesses;
    }

    @Override
    public void deleteSentMenfess(int menfessId) throws Exception {
        if (menfessId <= 0) {
            throw new IllegalArgumentException("Menfess ID must be positive");
        }
        List<Menfess> sent = menfessRepository.getAllMenfessesByUser(cosmic);
        Menfess toDelete = null;
        for (Menfess m : sent) {
            if (m.getId() == menfessId) {
                toDelete = m;
                break;
            }
        }
        if (toDelete == null) {
            throw new Exception("Menfess ID " + menfessId + " tidak ditemukan atau bukan milik anda.");
        }
        ((GenericRepositoryImpl<Menfess>) menfessRepository).remove(toDelete);
    }

    @Override
    public List<User> getTopCosmics(int n) throws EmptyListException {
        if (n <= 0) {
            throw new IllegalArgumentException("Number of top cosmics must be positive");
        }
        List<User> users = userRepository.getAllUsers();
        users.removeIf(u -> !"Cosmic".equals(u.getRole()));
        users.sort((u1, u2) -> {
            int c1 = menfessRepository.getAllMenfessesByUser(u1).size();
            int c2 = menfessRepository.getAllMenfessesByUser(u2).size();
            if (c1 != c2) return Integer.compare(c2, c1);
            return u1.getUsername().compareTo(u2.getUsername());
        });
        return users.subList(0, Math.min(n, users.size()));
    }

    @Override
    public int getCosmicRank(String username) throws EmptyListException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        List<User> users = userRepository.getAllUsers();
        users.removeIf(u -> !"Cosmic".equals(u.getRole()));
        users.sort((u1, u2) -> {
            int c1 = menfessRepository.getAllMenfessesByUser(u1).size();
            int c2 = menfessRepository.getAllMenfessesByUser(u2).size();
            if (c1 != c2) return Integer.compare(c2, c1);
            return u1.getUsername().compareTo(u2.getUsername());
        });
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(username)) return i + 1;
        }
        return -1;
    }

    @Override
    public int getMenfessCount(String username) throws EmptyListException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        User user = userRepository.getUserByUsername(username);
        if (user == null) return 0;
        return menfessRepository.getAllMenfessesByUser(user).size();
    }

    @Override
    public List<Menfess> getAllSentMenfesses() {
        return menfessRepository.getAllMenfessesByUser(cosmic);
    }

    @Override
    public List<Menfess> getAllReceivedMenfesses() {
        return menfessRepository.getAllMenfessesForUser(cosmic);
    }

    @Override
    public void changePassword(String newPassword) throws SamePasswordException {
        if (newPassword == null || newPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("New password cannot be null or empty");
        }
        if (cosmic.getPassword().equals(newPassword)) {
            throw new SamePasswordException("Password yang dimasukkan tidak boleh sama dengan password sebelumnya");
        }
        userRepository.changePassword(cosmic, newPassword);
    }

    @Override
    public void logout() {
        // No-op; handled by display
    }

    private void validateContent(String content) throws EmptyContentException {
        if (content == null || content.trim().isEmpty()) {
            throw new EmptyContentException("Isi menfess tidak boleh kosong.");
        }
    }
}
package burhanfess.services;

import burhanfess.exceptions.*;
import burhanfess.menfess.Menfess;
import burhanfess.repositories.*;
import burhanfess.users.Admin;
import burhanfess.users.User;

import java.util.*;
import java.io.FileWriter;

import burhanfess.log.LoginLogger;

public class AdminServiceImpl implements AdminService {
    private final UserRepository userRepository;
    private final MenfessRepository menfessRepository;

    public AdminServiceImpl() {
        this.userRepository = UserRepositoryImpl.getInstance();
        this.menfessRepository = MenfessRepositoryImpl.getInstance();
    }

    @Override
    public List<User> getAllUsers(Comparator<User> comparator) throws EmptyListException {
        if (comparator == null) {
            throw new IllegalArgumentException("Comparator cannot be null");
        }
        List<User> users = userRepository.getAllUsers();
        if (users == null || users.isEmpty()) {
            throw new EmptyListException("Tidak ada pengguna.");
        }
        users.sort(comparator);
        return users;
    }

    @Override
    public void addAdmin(String username, String password) throws UserAlreadyExistsException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        if (userRepository.getUserByUsername(username) != null) {
            throw new UserAlreadyExistsException("User dengan username '" + username + "' sudah ada");
        }
        userRepository.addUser(new Admin(username, password));
    }

    @Override
    public void resetPassword(String username, String newPassword) throws UserNotFoundException, SamePasswordException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (newPassword == null || newPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("New password cannot be null or empty");
        }
        User user = userRepository.getUserByUsername(username);
        if (user == null) {
            throw new UserNotFoundException("User dengan username '" + username + "' tidak ditemukan");
        }
        if (user.getPassword().equals(newPassword)) {
            throw new SamePasswordException("Password yang dimasukkan tidak boleh sama dengan password sebelumnya");
        }
        userRepository.changePassword(user, newPassword);
    }

    @Override
    public List<Menfess> getAllHiddenMenfesses() {
        List<Menfess> menfesses = menfessRepository.getAllHiddenMenfesses();
        return menfesses != null ? menfesses : new ArrayList<>();
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() throws EmptyListException {
        List<Menfess> menfesses = menfessRepository.getAllUnhiddenMenfesses();
        if (menfesses == null || menfesses.isEmpty()) {
            throw new EmptyListException("Tidak ada menfess yang dapat disembunyikan.");
        }
        return menfesses;
    }

    @Override
    public void hideMenfess(int menfessId) {
        if (menfessId <= 0) {
            throw new IllegalArgumentException("Menfess ID must be positive");
        }
        List<Menfess> menfesses = menfessRepository.getAllUnhiddenMenfesses();
        for (Menfess m : menfesses) {
            if (m.getId() == menfessId) {
                menfessRepository.hideMenfess(m);
                return;
            }
        }
        throw new RuntimeException("Menfess dengan ID " + menfessId + " tidak ditemukan.");
    }

    @Override
    public void unhideMenfess(int menfessId) {
        if (menfessId <= 0) {
            throw new IllegalArgumentException("Menfess ID must be positive");
        }
        List<Menfess> menfesses = menfessRepository.getAllHiddenMenfesses();
        for (Menfess m : menfesses) {
            if (m.getId() == menfessId) {
                menfessRepository.unhideMenfess(m);
                return;
            }
        }
        throw new RuntimeException("Menfess dengan ID " + menfessId + " tidak ditemukan.");
    }

    @Override
    @SuppressWarnings("all")
    public void deleteCosmicAccount(String username) throws CosmicAccountNotFoundException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        User user = userRepository.getUserByUsername(username);
        if (user == null || !"Cosmic".equals(user.getRole())) {
            throw new CosmicAccountNotFoundException("Username tidak ditemukan atau bukan akun Cosmic.");
        }

        List<Menfess> sent = new ArrayList<>(menfessRepository.getAllMenfessesByUser(user));
        for (Menfess m : sent) {
            ((GenericRepositoryImpl<Menfess>) menfessRepository).remove(m);
        }

        List<Menfess> received = new ArrayList<>(menfessRepository.getAllMenfessesForUser(user));
        for (Menfess m : received) {
            ((GenericRepositoryImpl<Menfess>) menfessRepository).remove(m);
        }

        ((GenericRepositoryImpl<User>) userRepository).remove(user);
        System.out.println("Berhasil menghapus user cosmic " + username + ".");
    }

    @Override
    public void exportLoginLogToFile(String filename) throws FileOperationException {
        if (filename == null || filename.trim().isEmpty()) {
            throw new IllegalArgumentException("Filename cannot be null or empty");
        }
        Map<String, List<String>> logMap = LoginLogger.getLogMap();
        List<String[]> allLogs = new ArrayList<>();
        for (Map.Entry<String, List<String>> entry : logMap.entrySet()) {
            for (String log : entry.getValue()) {
                allLogs.add(new String[] {entry.getKey(), log});
            }
        }

        allLogs.sort(Comparator.comparing(a -> a[1]));

        // Precompute streaks for Cosmic users
        Map<String, Integer> streaks = new HashMap<>();
        try {
            List<User> users = userRepository.getAllUsers();
            for (User u : users) {
                if ("Cosmic".equals(u.getRole())) {
                    int s = LoginLogger.getCurrentDailyStreak(u.getUsername());
                    streaks.put(u.getUsername(), s);
                }
            }
        } catch (Exception ignored) {
            // If user listing fails, we still write logs without streaks
        }

        try (FileWriter fw = new FileWriter(filename)) {
            fw.write("Username Tanggal Jam Streak\n");
            for (String[] log : allLogs) {
                String user = log[0];
                String ts = log[1];
                Integer streak = streaks.get(user);
                // Only show streak for Cosmic users; others as 0
                int toWrite = (streak != null) ? streak : 0;
                fw.write(user + " " + ts + " " + toWrite + "\n");
            }
        } catch (Exception e) {
            throw new FileOperationException("Gagal membuat file log: " + e.getMessage());
        }
        System.out.println("Berhasil membuat file " + filename + ".");
    }

    @Override
    public List<String[]> getCosmicStatistics() throws EmptyListException {
        // Check if repository is properly initialized
        if (userRepository == null || menfessRepository == null) {
            throw new IllegalStateException("Repositories not properly initialized");
        }

        // Get users with explicit null check
        List<User> users = userRepository.getAllUsers();
        if (users == null) {
            throw new EmptyListException("Gagal mengambil data pengguna");
        }

        List<String[]> statistics = new ArrayList<>();

        // Process each user
        for (User user : users) {
            // Skip null users and non-Cosmic users
            if (user == null || !"Cosmic".equals(user.getRole())) {
                continue;
            }

            // Initialize counters
            int confessCount = 0;
            int curhatCount = 0;
            int promosiCount = 0;

            try {
                // Get menfesses by user with null check
                List<Menfess> userMenfesses = menfessRepository.getAllMenfessesByUser(user);
                if (userMenfesses != null) {
                    for (Menfess menfess : userMenfesses) {
                        if (menfess == null) continue;

                        // Use instanceof instead of getType()
                        if (menfess instanceof burhanfess.menfess.ConfessFess) {
                            confessCount++;
                        } else if (menfess instanceof burhanfess.menfess.CurhatFess) {
                            curhatCount++;
                        } else if (menfess instanceof burhanfess.menfess.PromosiFess) {
                            promosiCount++;
                        }
                    }
                }

                // Get received menfesses with null check
                List<Menfess> receivedMenfesses = menfessRepository.getAllMenfessesForUser(user);
                int receivedCount = (receivedMenfesses != null) ? receivedMenfesses.size() : 0;

                // Add to statistics
                statistics.add(new String[] {
                        user.getUsername(),
                        String.valueOf(confessCount),
                        String.valueOf(curhatCount),
                        String.valueOf(promosiCount),
                        String.valueOf(receivedCount)
                });
            } catch (Exception e) {
                // Log error but continue processing other users
                System.err.println("Error processing user " + user.getUsername() + ": " + e.getMessage());
            }
        }

        if (statistics.isEmpty()) {
            throw new EmptyListException("Tidak ada data statistik yang tersedia.");
        }

        // Sort by username
        statistics.sort(Comparator.comparing(stat -> stat[0]));

        return statistics;
    }

    @Override
    public void logout() {
        // No-op; handled by display
    }
}
package burhanfess.services;

import burhanfess.exceptions.UserAlreadyExistsException;
import burhanfess.exceptions.UserNotFoundException;
import burhanfess.exceptions.InvalidCredentialsException;
import burhanfess.users.User;

public interface UnauthorizedService {
    void register(String username, String password) throws UserAlreadyExistsException;
    User login(String username, String password) throws UserNotFoundException, InvalidCredentialsException;
    void exit();
}
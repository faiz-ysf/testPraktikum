package burhanfess.services;

import burhanfess.repositories.UserRepository;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.exceptions.InvalidCredentialsException;
import burhanfess.exceptions.UserAlreadyExistsException;
import burhanfess.exceptions.UserNotFoundException;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import burhanfess.log.LoginLogger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UnauthorizedServiceImpl implements UnauthorizedService {
    private final UserRepository userRepository;

    public UnauthorizedServiceImpl() {
        this.userRepository = UserRepositoryImpl.getInstance();
    }

    @Override
    public void register(String username, String password) throws UserAlreadyExistsException {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password atau Username tidak boleh kosong!");
        }
        if (userRepository.getUserByUsername(username) != null) {
            throw new UserAlreadyExistsException("User dengan username '" + username + "' sudah ada");
        }
        userRepository.addUser(new Cosmic(username, password));
    }

    @Override
    public User login(String username, String password) throws UserNotFoundException, InvalidCredentialsException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        User user = userRepository.getUserByUsername(username);
        if (user == null) {
            throw new UserNotFoundException("User dengan username '" + username + "' tidak ditemukan");
        }
        if (!user.getPassword().equals(password)) {
            throw new InvalidCredentialsException("Username atau password salah.");
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String now = LocalDateTime.now().format(formatter);
        LoginLogger.log(user.getUsername(), now);
        System.out.println("Berhasil Menyimpan Log \"" + user.getUsername() + " - " + now + "\"");

        return user;
    }

    @Override
    public void exit() {
        System.out.println("Terima kasih telah menggunakan Burhanfess. Sampai jumpa!");
        System.exit(0);
    }
}
package burhanfess.services;

import burhanfess.exceptions.EmptyListException;
import burhanfess.exceptions.SamePasswordException;
import burhanfess.exceptions.UserAlreadyExistsException;
import burhanfess.exceptions.UserNotFoundException;
import burhanfess.exceptions.CosmicAccountNotFoundException;
import burhanfess.exceptions.FileOperationException;
import burhanfess.menfess.Menfess;
import burhanfess.users.User;
import java.util.Comparator;
import java.util.List;

public interface AdminService {
    List<User> getAllUsers(Comparator<User> comparator) throws EmptyListException;
    void addAdmin(String username, String password) throws UserAlreadyExistsException;
    void resetPassword(String username, String newPassword) throws UserNotFoundException, SamePasswordException;
    List<Menfess> getAllHiddenMenfesses();
    List<Menfess> getAllUnhiddenMenfesses() throws EmptyListException;
    void hideMenfess(int menfessId);
    void unhideMenfess(int menfessId);
    void deleteCosmicAccount(String username) throws CosmicAccountNotFoundException;
    void exportLoginLogToFile(String filename) throws FileOperationException;
    List<String[]> getCosmicStatistics() throws EmptyListException;
    @SuppressWarnings("all") void logout();
}
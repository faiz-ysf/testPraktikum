package burhanfess.services;

import burhanfess.exceptions.EmptyContentException;
import burhanfess.exceptions.EmptyListException;
import burhanfess.exceptions.SamePasswordException;
import burhanfess.exceptions.UserNotFoundException;
import burhanfess.menfess.Menfess;
import burhanfess.users.Cosmic;
import burhanfess.users.User;

import java.util.List;

public interface CosmicService {
    void sendCurhatFess(String content) throws EmptyContentException;
    void sendPromosiFess(String content) throws EmptyContentException;
    void sendConfessFess(String content, String receiverUsername) throws UserNotFoundException, EmptyContentException;
    void deleteSentMenfess(int menfessId) throws Exception;
    List<Menfess> getAllUnhiddenMenfesses() throws EmptyListException;
    List<Menfess> getAllSentMenfesses() throws EmptyListException;
    List<Menfess> getAllReceivedMenfesses() throws EmptyListException;
    List<User> getTopCosmics(int n) throws EmptyListException;
    int getCosmicRank(String username) throws EmptyListException;
    int getMenfessCount(String username) throws EmptyListException;
    void changePassword(String newPassword) throws SamePasswordException;
    void logout();
}
package test.repositoriesTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import burhanfess.repositories.GenericRepositoryImpl;
import static org.junit.jupiter.api.Assertions.*;

class GenericRepositoryImplTest {
    private GenericRepositoryImpl<String> repository;

    @BeforeEach
    void setUp() {
        repository = new GenericRepositoryImpl<>();
    }

    @Test
    void add_shouldAddObjectToRepository() {
        String testObject = "Test Object";
        repository.add(testObject);

        List<String> allObjects = repository.getAll();
        assertEquals(1, allObjects.size());
        assertTrue(allObjects.contains(testObject));
    }

    @Test
    void add_shouldThrowExceptionWhenAddingNull() {
        assertThrows(IllegalArgumentException.class, () -> repository.add(null));
    }

    @Test
    void remove_shouldRemoveObjectFromRepository() {
        String testObject = "Test Object";
        repository.add(testObject);

        repository.remove(testObject);
        List<String> allObjects = repository.getAll();
        assertEquals(0, allObjects.size());
    }

    @Test
    void remove_shouldThrowExceptionWhenRemovingNull() {
        assertThrows(IllegalArgumentException.class, () -> repository.remove(null));
    }

    @Test
    void getAll_shouldReturnAllObjects() {
        String object1 = "Object 1";
        String object2 = "Object 2";
        repository.add(object1);
        repository.add(object2);

        List<String> allObjects = repository.getAll();
        assertEquals(2, allObjects.size());
        assertTrue(allObjects.contains(object1));
        assertTrue(allObjects.contains(object2));
    }

    @Test
    void getAll_shouldReturnEmptyListWhenRepositoryIsEmpty() {
        List<String> allObjects = repository.getAll();
        assertTrue(allObjects.isEmpty());
    }
}
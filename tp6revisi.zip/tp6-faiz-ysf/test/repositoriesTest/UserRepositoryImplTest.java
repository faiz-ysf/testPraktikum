package test.repositoriesTest;


import burhanfess.exceptions.EmptyListException;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import burhanfess.repositories.UserRepositoryImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class UserRepositoryImplTest {
    private UserRepositoryImpl repository;

    @BeforeEach
    void setUp() {
        repository = new UserRepositoryImpl();
    }

    @Test
    void getAllUsers_shouldReturnAllUsers() throws EmptyListException {
        User user1 = new Cosmic("user1", "password");
        User user2 = new Cosmic("user2", "password");

        repository.addUser(user1);
        repository.addUser(user2);

        List<User> users = repository.getAllUsers();
        assertEquals(3, users.size()); // Includes default admin
        assertTrue(users.contains(user1));
        assertTrue(users.contains(user2));
    }

    @Test
    void getAllUsers_shouldThrowExceptionWhenNoUsers() {
        // Clear the default admin
        repository = new UserRepositoryImpl() {
            protected void initializeDefaultAdmin() {
                // Do nothing to skip adding default admin
            }
        };

        assertThrows(EmptyListException.class, () -> repository.getAllUsers());
    }

    @Test
    void getUserByUsername_shouldReturnCorrectUser() {
        User user = new Cosmic("testuser", "password");
        repository.addUser(user);

        User foundUser = repository.getUserByUsername("testuser");
        assertNotNull(foundUser);
        assertEquals(user, foundUser);
    }

    @Test
    void getUserByUsername_shouldReturnNullWhenUserNotFound() {
        User foundUser = repository.getUserByUsername("nonexistent");
        assertNull(foundUser);
    }

    @Test
    void addUser_shouldAddUserToRepository() {
        User user = new Cosmic("newuser", "password");
        repository.addUser(user);

        User foundUser = repository.getUserByUsername("newuser");
        assertNotNull(foundUser);
        assertEquals(user, foundUser);
    }

    @Test
    void changePassword_shouldChangeUserPassword() {
        User user = new Cosmic("testuser", "oldpassword");
        repository.addUser(user);

        repository.changePassword(user, "newpassword");
        assertEquals("newpassword", user.getPassword());
    }

    @Test
    void initializeDefaultAdmin_shouldAddDefaultAdmin() {
        User admin = repository.getUserByUsername("FYR");
        assertNotNull(admin);
        assertTrue(admin instanceof Admin);
        assertEquals("admin123", admin.getPassword());
    }
}
package test.repositoriesTest;

import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.repositories.MenfessRepositoryImpl;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MenfessRepositoryImplTest {
    private MenfessRepositoryImpl repository;
    private User sender;
    private User receiver;

    @BeforeEach
    void setUp() {
        repository = new MenfessRepositoryImpl();
        sender = new Cosmic("sender", "password");
        receiver = new Cosmic("receiver", "password");
    }

    @Test
    void addMenfess_shouldAddMenfessToRepository() {
        Menfess menfess = new CurhatFess(sender, "Test content");
        repository.addMenfess(menfess);

        List<Menfess> allMenfesses = repository.getAllMenfessesByUser(sender);
        assertEquals(1, allMenfesses.size());
        assertEquals(menfess, allMenfesses.get(0));
    }

    @Test
    void getAllMenfessesByUser_shouldReturnOnlyUserMenfesses() {
        Menfess menfess1 = new CurhatFess(sender, "Content 1");
        Menfess menfess2 = new CurhatFess(receiver, "Content 2");

        repository.addMenfess(menfess1);
        repository.addMenfess(menfess2);

        List<Menfess> senderMenfesses = repository.getAllMenfessesByUser(sender);
        assertEquals(1, senderMenfesses.size());
        assertEquals(menfess1, senderMenfesses.get(0));
    }

    @Test
    void getAllHiddenMenfesses_shouldReturnOnlyHiddenMenfesses() {
        Menfess hiddenMenfess = new CurhatFess(sender, "Hidden content");
        hiddenMenfess.hide();
        Menfess visibleMenfess = new CurhatFess(sender, "Visible content");

        repository.addMenfess(hiddenMenfess);
        repository.addMenfess(visibleMenfess);

        List<Menfess> hiddenMenfesses = repository.getAllHiddenMenfesses();
        assertEquals(1, hiddenMenfesses.size());
        assertEquals(hiddenMenfess, hiddenMenfesses.get(0));
    }

    @Test
    void getAllUnhiddenMenfesses_shouldReturnOnlyVisibleMenfesses() {
        Menfess hiddenMenfess = new CurhatFess(sender, "Hidden content");
        hiddenMenfess.hide();
        Menfess visibleMenfess = new CurhatFess(sender, "Visible content");

        repository.addMenfess(hiddenMenfess);
        repository.addMenfess(visibleMenfess);

        List<Menfess> visibleMenfesses = repository.getAllUnhiddenMenfesses();
        assertEquals(1, visibleMenfesses.size());
        assertEquals(visibleMenfess, visibleMenfesses.get(0));
    }

    @Test
    void hideMenfess_shouldHideMenfess() {
        Menfess menfess = new CurhatFess(sender, "Test content");
        repository.addMenfess(menfess);

        repository.hideMenfess(menfess);
        assertTrue(menfess.isHidden());
    }

    @Test
    void hideMenfess_shouldThrowExceptionWhenMenfessNotFound() {
        Menfess menfess = new CurhatFess(sender, "Test content");
        assertThrows(RuntimeException.class, () -> repository.hideMenfess(menfess));
    }

    @Test
    void unhideMenfess_shouldUnhideMenfess() {
        Menfess menfess = new CurhatFess(sender, "Test content");
        menfess.hide();
        repository.addMenfess(menfess);

        repository.unhideMenfess(menfess);
        assertFalse(menfess.isHidden());
    }

    @Test
    void getAllMenfessesForUser_shouldReturnReceivedConfessFesses() {
        Menfess confessFess = new ConfessFess(sender, "Confess content", receiver);
        Menfess curhatFess = new CurhatFess(sender, "Curhat content");

        repository.addMenfess(confessFess);
        repository.addMenfess(curhatFess);

        List<Menfess> receivedMenfesses = repository.getAllMenfessesForUser(receiver);
        assertEquals(1, receivedMenfesses.size());
        assertEquals(confessFess, receivedMenfesses.get(0));
    }
}
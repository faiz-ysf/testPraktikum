package test.serviceTest;

import burhanfess.exceptions.*;
import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.menfess.PromosiFess;
import burhanfess.repositories.MenfessRepositoryImpl;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.services.CosmicServiceImpl;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("all")
public class CosmicServiceImplTest {
    private CosmicServiceImpl cosmicService;
    private Cosmic cosmic;
    private UserRepositoryImpl userRepository;
    private MenfessRepositoryImpl menfessRepository;

    @BeforeEach
    void setUp() throws EmptyListException {
        // Create fresh instances for each test
        userRepository = (UserRepositoryImpl) UserRepositoryImpl.getInstance();
        menfessRepository = (MenfessRepositoryImpl) MenfessRepositoryImpl.getInstance();

        // Clear any existing data to ensure clean test state
        userRepository.getAllUsers().clear();
        menfessRepository.getAll().clear();

        // Create a cosmic user for testing
        cosmic = new Cosmic("testuser", "password");
        userRepository.addUser(cosmic);

        // Create the service with our test user
        cosmicService = new CosmicServiceImpl(cosmic);
    }

    @AfterEach
    void tearDown() throws EmptyListException {
        // Clean up after each test
        userRepository.getAllUsers().clear();
        menfessRepository.getAll().clear();
    }

    @Test
    void sendCurhatFess_shouldAddCurhatFess() throws EmptyContentException {
        // Arrange
        String content = "Test content";

        // Act
        cosmicService.sendCurhatFess(content);

        // Assert
        List<Menfess> allMenfesses = menfessRepository.getAll();
        assertEquals(1, allMenfesses.size());
        assertTrue(allMenfesses.get(0) instanceof CurhatFess);
        assertEquals(content, allMenfesses.get(0).getContent());
    }

    @Test
    void sendCurhatFess_shouldThrowExceptionWhenEmpty() {
        // Arrange
        String content = "";

        // Act & Assert
        assertThrows(EmptyContentException.class, () -> cosmicService.sendCurhatFess(content));
    }

    @Test
    void sendPromosiFess_shouldAddPromosiFess() throws EmptyContentException {
        // Arrange
        String content = "Test content";

        // Act
        cosmicService.sendPromosiFess(content);

        // Assert
        List<Menfess> allMenfesses = menfessRepository.getAll();
        assertEquals(1, allMenfesses.size());
        assertTrue(allMenfesses.get(0) instanceof PromosiFess);
        assertEquals(content, allMenfesses.get(0).getContent());
    }

    @Test
    void sendConfessFess_shouldAddConfessFess() throws UserNotFoundException, EmptyContentException {
        // Arrange
        String content = "Test content";
        String receiverUsername = "receiver";
        Cosmic receiver = new Cosmic(receiverUsername, "pass");
        userRepository.addUser(receiver);

        // Act
        cosmicService.sendConfessFess(content, receiverUsername);

        // Assert
        List<Menfess> allMenfesses = menfessRepository.getAll();
        assertEquals(1, allMenfesses.size());
        assertTrue(allMenfesses.get(0) instanceof ConfessFess);
        assertEquals(content, allMenfesses.get(0).getContent());
        assertEquals(receiver, ((ConfessFess) allMenfesses.get(0)).getReceiver());
    }

    @Test
    void sendConfessFess_shouldThrowExceptionWhenUserNotFound() {
        // Arrange
        String content = "Test content";
        String receiverUsername = "nonexistent";

        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> cosmicService.sendConfessFess(content, receiverUsername));
    }

    @Test
    void getAllUnhiddenMenfesses_shouldReturnUnhiddenMenfesses() throws EmptyListException {
        // Arrange
        Menfess menfess = new CurhatFess(cosmic, "content");
        menfessRepository.addMenfess(menfess);

        // Act
        List<Menfess> result = cosmicService.getAllUnhiddenMenfesses();

        // Assert
        assertEquals(1, result.size());
        assertEquals(menfess, result.get(0));
    }

    @Test
    void getAllUnhiddenMenfesses_shouldThrowExceptionWhenEmpty() {
        // Arrange - no menfess added

        // Act & Assert
        assertThrows(EmptyListException.class, () -> cosmicService.getAllUnhiddenMenfesses());
    }

    @Test
    void deleteSentMenfess_shouldDeleteMenfess() throws Exception {
        // Arrange
        Menfess menfess = new CurhatFess(cosmic, "content");
        menfessRepository.addMenfess(menfess);

        // Act
        cosmicService.deleteSentMenfess(menfess.getId());

        // Assert
        assertTrue(menfessRepository.getAll().isEmpty());
    }

    @Test
    void deleteSentMenfess_shouldThrowExceptionWhenNotFound() {
        // Arrange - no menfess added

        // Act & Assert
        assertThrows(Exception.class, () -> cosmicService.deleteSentMenfess(999));
    }

    @Test
    void getTopCosmics_shouldReturnTopCosmics() throws EmptyListException {
        // Arrange
        Cosmic user1 = new Cosmic("user1", "pass");
        Cosmic user2 = new Cosmic("user2", "pass");
        userRepository.addUser(user1);
        userRepository.addUser(user2);

        // Add menfesses to create different counts
        menfessRepository.addMenfess(new CurhatFess(user1, "content"));
        menfessRepository.addMenfess(new CurhatFess(user1, "content"));
        menfessRepository.addMenfess(new CurhatFess(user2, "content"));

        // Act
        List<User> topCosmics = cosmicService.getTopCosmics(2);

        // Assert
        assertEquals(2, topCosmics.size());
        assertEquals("user1", topCosmics.get(0).getUsername()); // More menfesses
        assertEquals("user2", topCosmics.get(1).getUsername());
    }

    @Test
    void changePassword_shouldChangePassword() throws SamePasswordException {
        // Arrange
        String newPassword = "newpassword";

        // Act
        cosmicService.changePassword(newPassword);

        // Assert
        assertEquals(newPassword, cosmic.getPassword());
    }

    @Test
    void changePassword_shouldThrowExceptionWhenSamePassword() {
        // Arrange
        String samePassword = "password";

        // Act & Assert
        assertThrows(SamePasswordException.class, () -> cosmicService.changePassword(samePassword));
    }
}

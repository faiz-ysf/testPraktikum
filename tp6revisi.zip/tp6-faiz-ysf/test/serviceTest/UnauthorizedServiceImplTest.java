package test.serviceTest;

import burhanfess.exceptions.*;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.services.UnauthorizedServiceImpl;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UnauthorizedServiceImplTest {
    private UnauthorizedServiceImpl unauthorizedService;
    private UserRepositoryImpl userRepository;

    @BeforeEach
    void setUp() throws EmptyListException {
        // Create fresh instances for each test
        userRepository = (UserRepositoryImpl) UserRepositoryImpl.getInstance();
        unauthorizedService = new UnauthorizedServiceImpl();

        // Clear any existing data to ensure clean test state
        userRepository.getAllUsers().clear();
    }

    @AfterEach
    void tearDown() throws EmptyListException {
        // Clean up after each test
        userRepository.getAllUsers().clear();
    }

    @Test
    void register_shouldAddNewUser() throws UserAlreadyExistsException {
        // Arrange
        String username = "newuser";
        String password = "password";

        // Act
        unauthorizedService.register(username, password);

        // Assert
        User registeredUser = userRepository.getUserByUsername(username);
        assertNotNull(registeredUser);
        assertTrue(registeredUser instanceof Cosmic);
        assertEquals(username, registeredUser.getUsername());
        assertEquals(password, registeredUser.getPassword());
    }

    @Test
    void register_shouldThrowExceptionWhenUserExists() {
        // Arrange
        String username = "existing";
        userRepository.addUser(new Cosmic(username, "pass"));

        // Act & Assert
        assertThrows(UserAlreadyExistsException.class, () -> unauthorizedService.register(username, "password"));
    }

    @Test
    void login_shouldReturnUserWhenCredentialsValid() throws UserNotFoundException, InvalidCredentialsException {
        // Arrange
        String username = "testuser";
        String password = "password";
        User user = new Cosmic(username, password);
        userRepository.addUser(user);

        // Act
        User result = unauthorizedService.login(username, password);

        // Assert
        assertNotNull(result);
        assertEquals(user, result);
    }

    @Test
    void login_shouldThrowExceptionWhenUserNotFound() {
        // Arrange
        String username = "nonexistent";
        String password = "password";

        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> unauthorizedService.login(username, password));
    }

    @Test
    void login_shouldThrowExceptionWhenPasswordInvalid() {
        // Arrange
        String username = "testuser";
        String correctPassword = "correctpassword";
        String wrongPassword = "wrongpassword";
        User user = new Cosmic(username, correctPassword);
        userRepository.addUser(user);

        // Act & Assert
        assertThrows(InvalidCredentialsException.class, () -> unauthorizedService.login(username, wrongPassword));
    }
}

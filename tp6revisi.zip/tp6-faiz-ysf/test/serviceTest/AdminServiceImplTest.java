package test.serviceTest;

import burhanfess.exceptions.*;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.repositories.MenfessRepositoryImpl;
import burhanfess.repositories.UserRepositoryImpl;

import burhanfess.services.AdminServiceImpl;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import burhanfess.users.comparators.UserIdComparator;
import burhanfess.users.comparators.UserUsernameComparator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class AdminServiceImplTest {
    private AdminServiceImpl adminService;
    private UserRepositoryImpl userRepository;
    private MenfessRepositoryImpl menfessRepository;

    @BeforeEach
    void setUp() throws EmptyListException {
        // Create fresh instances for each test
        userRepository = (UserRepositoryImpl) UserRepositoryImpl.getInstance();
        menfessRepository = (MenfessRepositoryImpl) MenfessRepositoryImpl.getInstance();
        adminService = new AdminServiceImpl();

        // Clear any existing data to ensure clean test state
        userRepository.getAllUsers().clear();
        menfessRepository.getAll().clear();

        // Add a default admin for testing
        userRepository.addUser(new Admin("admin", "password"));
    }

    @AfterEach
    void tearDown() throws EmptyListException {
        // Clean up after each test
        userRepository.getAllUsers().clear();
        menfessRepository.getAll().clear();
    }

    @Test
    void getAllUsers_shouldReturnSortedUsers() throws EmptyListException {
        // Arrange
        User user1 = new Cosmic("user2", "pass");
        User user2 = new Cosmic("user1", "pass");
        userRepository.addUser(user1);
        userRepository.addUser(user2);

        // Act
        List<User> result = adminService.getAllUsers(new UserUsernameComparator());

        // Assert
        assertEquals(3, result.size()); // Includes default admin
        assertEquals("admin", result.get(0).getUsername());
        assertEquals("user1", result.get(1).getUsername());
        assertEquals("user2", result.get(2).getUsername());
    }

    @Test
    void getAllUsers_shouldThrowExceptionWhenEmpty() throws EmptyListException {
        // Arrange - clear all users
        userRepository.getAllUsers().clear();

        // Act & Assert
        assertThrows(EmptyListException.class, () -> adminService.getAllUsers(new UserIdComparator()));
    }

    @Test
    void addAdmin_shouldAddNewAdmin() throws UserAlreadyExistsException {
        // Arrange
        String username = "newadmin";
        String password = "password";

        // Act
        adminService.addAdmin(username, password);

        // Assert
        User addedAdmin = userRepository.getUserByUsername(username);
        assertNotNull(addedAdmin);
        assertTrue(addedAdmin instanceof Admin);
        assertEquals(username, addedAdmin.getUsername());
    }

    @Test
    void addAdmin_shouldThrowExceptionWhenUserExists() {
        // Arrange
        String username = "existing";
        userRepository.addUser(new Cosmic(username, "pass"));

        // Act & Assert
        assertThrows(UserAlreadyExistsException.class, () -> adminService.addAdmin(username, "password"));
    }

    @Test
    void resetPassword_shouldChangePassword() throws UserNotFoundException, SamePasswordException {
        // Arrange
        String username = "testuser";
        String oldPassword = "oldpass";
        String newPassword = "newpass";
        User user = new Cosmic(username, oldPassword);
        userRepository.addUser(user);

        // Act
        adminService.resetPassword(username, newPassword);

        // Assert
        User updatedUser = userRepository.getUserByUsername(username);
        assertEquals(newPassword, updatedUser.getPassword());
    }

    @Test
    void resetPassword_shouldThrowExceptionWhenSamePassword() {
        // Arrange
        String username = "testuser";
        String password = "password";
        User user = new Cosmic(username, password);
        userRepository.addUser(user);

        // Act & Assert
        assertThrows(SamePasswordException.class, () -> adminService.resetPassword(username, password));
    }

    @Test
    void hideMenfess_shouldHideMenfess() {
        // Arrange
        User user = new Cosmic("user", "pass");
        Menfess menfess = new CurhatFess(user, "content");
        menfessRepository.addMenfess(menfess);

        // Act
        adminService.hideMenfess(menfess.getId());

        // Assert
        assertTrue(menfess.isHidden());
    }

    @Test
    void hideMenfess_shouldThrowExceptionWhenNotFound() {
        // Arrange - no menfess added

        // Act & Assert
        assertThrows(RuntimeException.class, () -> adminService.hideMenfess(999));
    }

    @Test
    void deleteCosmicAccount_shouldDeleteUserAndMenfesses() throws CosmicAccountNotFoundException {
        // Arrange
        String username = "testuser";
        Cosmic user = new Cosmic(username, "pass");
        userRepository.addUser(user);

        Menfess menfess = new CurhatFess(user, "content");
        menfessRepository.addMenfess(menfess);

        // Act
        adminService.deleteCosmicAccount(username);

        // Assert
        assertNull(userRepository.getUserByUsername(username));
        assertTrue(menfessRepository.getAll().isEmpty());
    }

    @Test
    void deleteCosmicAccount_shouldThrowExceptionWhenNotFound() {
        // Arrange - no user added

        // Act & Assert
        assertThrows(CosmicAccountNotFoundException.class, () -> adminService.deleteCosmicAccount("nonexistent"));
    }

    @SuppressWarnings("all")
    @Test
    void getCosmicStatistics_shouldReturnStatistics() throws EmptyListException {
        // Arrange
        String username = "testuser";
        Cosmic user = new Cosmic(username, "pass");
        userRepository.addUser(user);

        Menfess menfess = new CurhatFess(user, "content");
        menfessRepository.addMenfess(menfess);

        // Act
        List<String[]> stats = adminService.getCosmicStatistics();

        // Assert
        assertEquals(1, stats.size());
        assertEquals(username, stats.get(0)[0]);
        assertEquals("0", stats.get(0)[1]); // Confess count
        assertEquals("1", stats.get(0)[2]); // Curhat count
        assertEquals("0", stats.get(0)[3]); // Promosi count
        assertEquals("0", stats.get(0)[4]); // Received count
    }
}

package test.usersTest;

import burhanfess.users.Cosmic;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CosmicTest {
    @Test
    void constructor_shouldInitializeFields() {
        // Arrange
        String username = "cosmicuser";
        String password = "password";

        // Act
        Cosmic cosmic = new Cosmic(username, password);

        // Assert
        assertEquals(username, cosmic.getUsername());
        assertEquals(password, cosmic.getPassword());
    }

    @Test
    void getRole_shouldReturnCosmic() {
        // Arrange
        Cosmic cosmic = new Cosmic("username", "password");

        // Act
        String role = cosmic.getRole();

        // Assert
        assertEquals("Cosmic", role);
    }

}

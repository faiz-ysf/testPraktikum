package test.usersTest;

import burhanfess.users.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {
    @Test
    void constructor_shouldInitializeFields() {
        // Arrange
        String username = "testuser";
        String password = "password";

        // Act - using a concrete subclass for testing
        TestUser user = new TestUser(username, password);

        // Assert
        assertEquals(username, user.getUsername());
        assertEquals(password, user.getPassword());
    }

    @Test
    void setPassword_shouldUpdatePassword() {
        // Arrange
        TestUser user = new TestUser("username", "oldpassword");
        String newPassword = "newpassword";

        // Act
        user.setPassword(newPassword);

        // Assert
        assertEquals(newPassword, user.getPassword());
    }

    @Test
    void getRole_shouldReturnCorrectRole() {
        // Arrange
        TestUser user = new TestUser("username", "password");

        // Act
        String role = user.getRole();

        // Assert
        assertEquals("Test", role);
    }

    // Helper class for testing abstract User
    private static class TestUser extends User {
        public TestUser(String username, String password) {
            super(username, password);
        }

        @Override
        public String getRole() {
            return "Test";
        }
    }
}

package test.usersTest;

import burhanfess.users.Admin;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdminTest {
    @Test
    void constructor_shouldInitializeFields() {
        // Arrange
        String username = "adminuser";
        String password = "password";

        // Act
        Admin admin = new Admin(username, password);

        // Assert
        assertEquals(username, admin.getUsername());
        assertEquals(password, admin.getPassword());
    }

    @Test
    void getRole_shouldReturnAdmin() {
        // Arrange
        Admin admin = new Admin("username", "password");

        // Act
        String role = admin.getRole();

        // Assert
        assertEquals("Admin", role);
    }
}

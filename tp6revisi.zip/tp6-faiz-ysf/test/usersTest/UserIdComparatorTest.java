package test.usersTest;

import burhanfess.users.User;
import burhanfess.users.comparators.UserIdComparator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserIdComparatorTest {
    @Test
    void compare_shouldReturnNegativeWhenFirstIdIsLess() {
        // Arrange
        UserIdComparator comparator = new UserIdComparator();
        User user1 = new TestUser(1, "user1", "pass");
        User user2 = new TestUser(2, "user2", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertTrue(result < 0);
    }

    @Test
    void compare_shouldReturnPositiveWhenFirstIdIsGreater() {
        // Arrange
        UserIdComparator comparator = new UserIdComparator();
        User user1 = new TestUser(2, "user1", "pass");
        User user2 = new TestUser(1, "user2", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertTrue(result > 0);
    }

    @Test
    void compare_shouldReturnZeroWhenIdsAreEqual() {
        // Arrange
        UserIdComparator comparator = new UserIdComparator();
        User user1 = new TestUser(1, "user1", "pass");
        User user2 = new TestUser(1, "user2", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertEquals(0, result);
    }

    // Helper class for testing with controlled IDs
    private static class TestUser extends User {
        private final int id;

        public TestUser(int id, String username, String password) {
            super(username, password);
            this.id = id;
        }

        @Override
        public int getId() {
            return id;
        }

        @Override
        public String getRole() {
            return "Test";
        }
    }
}

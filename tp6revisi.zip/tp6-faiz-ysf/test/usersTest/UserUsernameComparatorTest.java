package test.usersTest;

import burhanfess.users.User;
import burhanfess.users.Cosmic;
import burhanfess.users.comparators.UserUsernameComparator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserUsernameComparatorTest {
    @Test
    void compare_shouldReturnNegativeWhenFirstUsernameIsLess() {
        // Arrange
        UserUsernameComparator comparator = new UserUsernameComparator();
        User user1 = new Cosmic("alice", "pass");
        User user2 = new Cosmic("bob", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertTrue(result < 0);
    }

    @Test
    void compare_shouldReturnPositiveWhenFirstUsernameIsGreater() {
        // Arrange
        UserUsernameComparator comparator = new UserUsernameComparator();
        User user1 = new Cosmic("bob", "pass");
        User user2 = new Cosmic("alice", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertTrue(result > 0);
    }

    @Test
    void compare_shouldReturnZeroWhenUsernamesAreEqual() {
        // Arrange
        UserUsernameComparator comparator = new UserUsernameComparator();
        User user1 = new Cosmic("alice", "pass1");
        User user2 = new Cosmic("alice", "pass2");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        assertEquals(0, result);
    }

    @Test
    void compare_shouldBeCaseSensitive() {
        // Arrange
        UserUsernameComparator comparator = new UserUsernameComparator();
        User user1 = new Cosmic("Alice", "pass");
        User user2 = new Cosmic("alice", "pass");

        // Act
        int result = comparator.compare(user1, user2);

        // Assert
        // 'A' (65) has a lower ASCII value than 'a' (97), so result should be negative
        assertTrue(result < 0);
    }
}

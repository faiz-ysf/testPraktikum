package test.menfessTest;

import burhanfess.menfess.ConfessFess;
import burhanfess.users.Cosmic;
import burhanfess.users.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ConfessFessTest {
    @Test
    void constructor_shouldInitializeWithUserContentAndReceiver() {
        // Arrange
        Cosmic sender = new Cosmic("sender", "password");
        Cosmic receiver = new Cosmic("receiver", "password");
        String content = "I have a crush on you";

        // Act
        ConfessFess confessFess = new ConfessFess(sender, content, receiver);

        // Assert
        assertEquals(sender, confessFess.getUser());
        assertEquals(content, confessFess.getContent());
        assertEquals(receiver, confessFess.getReceiver());
        assertFalse(confessFess.isHidden());
    }

    @Test
    void getType_shouldReturnConfessFess() {
        // Arrange
        ConfessFess confessFess = new ConfessFess(
                new Cosmic("sender", "pass"),
                "content",
                new Cosmic("receiver", "pass")
        );

        // Act
        String type = confessFess.getType();

        // Assert
        assertEquals("ConfessFess", type);
    }

    @Test
    void getReceiver_shouldReturnCorrectReceiver() {
        // Arrange
        Cosmic sender = new Cosmic("sender", "password");
        Cosmic receiver = new Cosmic("receiver", "password");
        ConfessFess confessFess = new ConfessFess(sender, "content", receiver);

        // Act
        User result = confessFess.getReceiver();

        // Assert
        assertEquals(receiver, result);
    }
}

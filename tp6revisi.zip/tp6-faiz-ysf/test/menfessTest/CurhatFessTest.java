package test.menfessTest;

import burhanfess.menfess.CurhatFess;
import burhanfess.users.Cosmic;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CurhatFessTest {
    @Test
    void constructor_shouldInitializeWithUserAndContent() {
        // Arrange
        Cosmic user = new Cosmic("testuser", "password");
        String content = "This is a curhat";

        // Act
        CurhatFess curhatFess = new CurhatFess(user, content);

        // Assert
        assertEquals(user, curhatFess.getUser());
        assertEquals(content, curhatFess.getContent());
        assertFalse(curhatFess.isHidden());
    }

    @Test
    void getType_shouldReturnCurhatFess() {
        // Arrange
        CurhatFess curhatFess = new CurhatFess(new Cosmic("user", "pass"), "content");

        // Act
        String type = curhatFess.getType();

        // Assert
        assertEquals("CurhatFess", type);
    }
}

package test.menfessTest;

import burhanfess.menfess.Menfess;
import burhanfess.users.Cosmic;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MenfessTest {
    @Test
    void constructor_shouldInitializeFields() {
        // Arrange
        Cosmic user = new Cosmic("testuser", "password");
        String content = "Test content";

        // Act - using a concrete subclass for testing
        TestMenfess menfess = new TestMenfess(user, content);

        // Assert
        assertEquals(user, menfess.getUser());
        assertEquals(content, menfess.getContent());
        assertFalse(menfess.isHidden());
        assertTrue(menfess.getId() > 0);
    }

    @Test
    void hide_shouldSetHiddenToTrue() {
        // Arrange
        TestMenfess menfess = new TestMenfess(new Cosmic("user", "pass"), "content");

        // Act
        menfess.hide();

        // Assert
        assertTrue(menfess.isHidden());
    }

    @Test
    void unhide_shouldSetHiddenToFalse() {
        // Arrange
        TestMenfess menfess = new TestMenfess(new Cosmic("user", "pass"), "content");
        menfess.hide(); // First hide it

        // Act
        menfess.unhide();

        // Assert
        assertFalse(menfess.isHidden());
    }

    // Helper class for testing abstract Menfess
    private static class TestMenfess extends Menfess {
        public TestMenfess(Cosmic user, String content) {
            super(user, content);
        }

        @Override
        public String getType() {
            return "TestFess";
        }
    }
}
package test.menfessTest;

import burhanfess.menfess.PromosiFess;
import burhanfess.users.Cosmic;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PromosiFessTest {
    @Test
    void constructor_shouldInitializeWithUserAndContent() {
        // Arrange
        Cosmic user = new Cosmic("testuser", "password");
        String content = "Check out this product!";

        // Act
        PromosiFess promosiFess = new PromosiFess(user, content);

        // Assert
        assertEquals(user, promosiFess.getUser());
        assertEquals(content, promosiFess.getContent());
        assertFalse(promosiFess.isHidden());
    }

    @Test
    void getType_shouldReturnPromosiFess() {
        // Arrange
        PromosiFess promosiFess = new PromosiFess(new Cosmic("user", "pass"), "content");

        // Act
        String type = promosiFess.getType();

        // Assert
        assertEquals("PromosiFess", type);
    }
}
